
// src/templates/theme/index.php.hbs
<?php get_header(); ?>
<div class="content">
  <h1>Welcome to Usman Hardware</h1>
  <section class="Gallery">Gallery Content</section>
  <section class="Contact">Contact Content</section>
  <div class="Contact Forms">Contact Forms Feature</div>
  <div class="About Us Page">About Us Page Feature</div>
  <div class="Speed Optimization">Speed Optimization Feature</div>
  <div class="CDN Integration">CDN Integration Feature</div>
</div>
<?php get_footer(); ?>