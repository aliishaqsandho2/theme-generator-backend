
// src/templates/theme/index.php.hbs
<?php get_header(); ?>
<div class="content">
  <h1>Welcome to Usman Hardware</h1>
  <section class="Hero/Banner">Hero/Banner Content</section>
  <section class="About Us">About Us Content</section>
  <section class="Services">Services Content</section>
  <div class="Contact Forms">Contact Forms Feature</div>
  <div class="About Us Page">About Us Page Feature</div>
  <div class="Services/Products">Services/Products Feature</div>
</div>
<?php get_footer(); ?>