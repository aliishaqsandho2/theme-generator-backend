
<?php
function Usman Hardware_theme_setup() {
  add_theme_support('title-tag');
  register_nav_menus(array(
    'primary' => __('Primary Menu', 'Usman Hardware'),
  ));
  add_theme_support('post-thumbnails');
}
add_action('after_setup_theme', 'Usman Hardware_theme_setup');
?>

